using UnityEngine;

namespace PublicBS.Settings
{
    public sealed class settingsUI : MonoBehaviour
    {
        public bool GridEnabled { get; private set; } = true;

        public void ToggleGrid()
        {
            GridEnabled = !GridEnabled;
            if (Bootstrap.GameBootstrap.Instance != null)
                Bootstrap.GameBootstrap.Instance.SetGridVisible(GridEnabled);
        }
    }
}
