using UnityEngine;

namespace PublicBS.Settings
{
    public sealed class SoundSettings : MonoBehaviour
    {
        public bool IsMuted { get; private set; }
        private float previousVolume = 1f;

        public void Toggle()
        {
            IsMuted = !IsMuted;
            if (IsMuted)
            {
                previousVolume = AudioListener.volume;
                AudioListener.volume = 0f;
            }
            else
            {
                AudioListener.volume = previousVolume <= 0f ? 1f : previousVolume;
            }
        }
    }
}
