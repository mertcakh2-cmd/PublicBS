using UnityEngine;

namespace PublicBS.Settings
{
    public sealed class AimAssist : MonoBehaviour
    {
        public bool SnapToGrid { get; set; } = true;

        public Vector3 Snap(Vector3 point, float gridSize)
        {
            if (!SnapToGrid) return point;
            return new Vector3(
                Mathf.Round(point.x / gridSize) * gridSize,
                point.y,
                Mathf.Round(point.z / gridSize) * gridSize);
        }
    }
}
