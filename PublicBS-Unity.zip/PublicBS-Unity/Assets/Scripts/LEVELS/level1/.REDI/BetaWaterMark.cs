// Kept as a compatibility entry point for the original project layout.
// The actual watermark component lives at Assets/Scripts/BootStrap/BetaWaterMark.cs.
namespace PublicBS.Levels.RedI
{
    internal static class BetaWaterMarkInfo
    {
        public const string Label = "PUBLICBS • CREATIVE BUILD";
    }
}
