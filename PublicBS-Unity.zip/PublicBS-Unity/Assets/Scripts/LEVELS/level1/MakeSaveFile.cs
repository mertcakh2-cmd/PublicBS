using System;
using System.Collections.Generic;
using UnityEngine;
using PublicBS.Objects;

namespace PublicBS.Levels
{
    [Serializable]
    public sealed class BuildSaveData
    {
        public int version = 1;
        public List<BuildObjectData> items = new List<BuildObjectData>();
    }
}
