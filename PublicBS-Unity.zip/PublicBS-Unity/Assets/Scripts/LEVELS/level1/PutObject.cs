using UnityEngine;
using UnityEngine.EventSystems;
using PublicBS.Bootstrap;
using PublicBS.Objects;
using PublicBS.Main;

namespace PublicBS.Levels
{
    public sealed class PutObject : MonoBehaviour
    {
        private Camera worldCamera;
        private Transform objectRoot;
        private PrimitiveType selectedPrimitive = PrimitiveType.Cube;
        private BuildObject lastPlaced;
        private bool deleteMode;
        private int colorIndex;
        private readonly Color[] palette =
        {
            new Color(0.12f, 0.72f, 0.95f), new Color(0.43f, 0.88f, 0.77f),
            new Color(0.54f, 0.47f, 0.96f), new Color(1.00f, 0.62f, 0.31f),
            new Color(0.96f, 0.39f, 0.52f), new Color(0.88f, 0.83f, 0.45f),
            new Color(0.57f, 0.72f, 0.98f), new Color(0.83f, 0.87f, 0.93f)
        };

        public bool DeleteMode => deleteMode;

        public void Initialize(Camera cameraToUse, Transform root)
        {
            worldCamera = cameraToUse;
            objectRoot = root;
        }

        private void Update()
        {
            if (worldCamera == null) return;
            if (Input.GetKeyDown(KeyCode.Q)) RotateLast(-45f);
            if (Input.GetKeyDown(KeyCode.E)) RotateLast(45f);
            if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.S)) SaveWorld();
            if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.L)) LoadWorld();

            if (Input.touchCount > 0)
            {
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch touch = Input.GetTouch(i);
                    if (touch.phase == TouchPhase.Began && !IsPointerOverUI(touch.fingerId))
                    {
                        HandlePointer(touch.position);
                        break;
                    }
                }
            }
            else if (Input.GetMouseButtonDown(0) && !IsPointerOverUI(-1))
            {
                HandlePointer(Input.mousePosition);
            }
        }

        private bool IsPointerOverUI(int pointerId)
        {
            return EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(pointerId);
        }

        private void HandlePointer(Vector2 screenPosition)
        {
            Ray ray = worldCamera.ScreenPointToRay(screenPosition);
            if (deleteMode)
            {
                if (Physics.Raycast(ray, out RaycastHit objectHit, 250f))
                {
                    BuildObject item = objectHit.collider.GetComponentInParent<BuildObject>();
                    if (item != null)
                    {
                        if (lastPlaced == item) lastPlaced = null;
                        Destroy(item.gameObject);
                    }
                }
                return;
            }

            Plane groundPlane = new Plane(Vector3.up, Vector3.zero);
            if (!groundPlane.Raycast(ray, out float enter) || enter < 0f) return;
            Vector3 point = ray.GetPoint(enter);
            float grid = GameBootstrap.Instance != null ? GameBootstrap.Instance.GridSize : 1f;
            point.x = Mathf.Round(point.x / grid) * grid;
            point.z = Mathf.Round(point.z / grid) * grid;
            PlaceAt(point, selectedPrimitive, palette[colorIndex++ % palette.Length]);
        }

        public void SetSelectedPrimitive(PrimitiveType type)
        {
            selectedPrimitive = type;
            deleteMode = false;
        }

        public void ToggleDeleteMode()
        {
            deleteMode = !deleteMode;
        }

        public BuildObject PlaceAt(Vector3 groundPosition, PrimitiveType primitive, Color color)
        {
            if (objectRoot == null) return null;
            GameObject instance = Placement.CreatePrimitive(primitive, groundPosition, color, objectRoot);
            BuildObject buildObject = instance.GetComponent<BuildObject>();
            lastPlaced = buildObject;
            return buildObject;
        }

        public void RotateLast() => RotateLast(45f);

        private void RotateLast(float degrees)
        {
            if (lastPlaced != null)
                lastPlaced.transform.Rotate(Vector3.up, degrees, Space.World);
        }

        public void ClearWorld()
        {
            if (objectRoot == null) return;
            for (int i = objectRoot.childCount - 1; i >= 0; i--)
                Destroy(objectRoot.GetChild(i).gameObject);
            lastPlaced = null;
        }

        public void SaveWorld()
        {
            CreateSave.Save(objectRoot);
        }

        public bool LoadWorld()
        {
            return Load.Restore(objectRoot, this);
        }

        public void RestoreItem(BuildObjectData data)
        {
            PrimitiveType primitive;
            if (!System.Enum.TryParse(data.primitive, out primitive)) primitive = PrimitiveType.Cube;
            GameObject obj = Placement.CreatePrimitive(primitive, data.position, data.color, objectRoot);
            obj.transform.position = data.position;
            obj.transform.eulerAngles = data.rotation;
            obj.transform.localScale = data.scale;
            BuildObject component = obj.GetComponent<BuildObject>();
            component.SetColor(data.color);
            lastPlaced = component;
        }
    }
}
