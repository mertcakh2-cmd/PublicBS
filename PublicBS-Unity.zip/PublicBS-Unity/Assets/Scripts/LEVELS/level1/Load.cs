using System.IO;
using UnityEngine;
using PublicBS.Objects;
using PublicBS.Main;

namespace PublicBS.Levels
{
    public static class Load
    {
        public static bool Restore(Transform root, PutObject placement)
        {
            string path = CreateSave.SavePath;
            if (!File.Exists(path)) return false;
            string json = File.ReadAllText(path);
            BuildSaveData save = JsonUtility.FromJson<BuildSaveData>(json);
            if (save == null || save.items == null) return false;

            for (int i = root.childCount - 1; i >= 0; i--)
                Object.Destroy(root.GetChild(i).gameObject);

            foreach (BuildObjectData item in save.items)
                placement.RestoreItem(item);
            return true;
        }
    }
}
