using UnityEngine;

namespace PublicBS.Main
{
    public sealed class StartGame : MonoBehaviour
    {
        public bool IsRunning { get; private set; }

        private void Start()
        {
            IsRunning = true;
            Debug.Log("PublicBS sandbox started.");
        }

        public void Pause(bool paused)
        {
            Time.timeScale = paused ? 0f : 1f;
            IsRunning = !paused;
        }
    }
}
