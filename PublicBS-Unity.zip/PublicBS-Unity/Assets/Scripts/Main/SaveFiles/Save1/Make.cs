using UnityEngine;

namespace PublicBS.Main.SaveFiles
{
    public static class Make
    {
        public static string CreateSlotName(int slot)
        {
            return "slot" + Mathf.Clamp(slot, 1, 5) + ".json";
        }
    }
}
