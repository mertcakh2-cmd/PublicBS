using System.IO;
using UnityEngine;
using PublicBS.Levels;
using PublicBS.Objects;

namespace PublicBS.Main
{
    public static class CreateSave
    {
        public static string SaveDirectory => Path.Combine(Application.persistentDataPath, "PublicBS");
        public static string SavePath => Path.Combine(SaveDirectory, "slot1.json");

        public static void Save(Transform root)
        {
            Directory.CreateDirectory(SaveDirectory);
            BuildSaveData data = new BuildSaveData();
            foreach (Transform child in root)
            {
                BuildObject item = child.GetComponent<BuildObject>();
                if (item != null) data.items.Add(item.ToData());
            }
            File.WriteAllText(SavePath, JsonUtility.ToJson(data, true));
            Debug.Log("PublicBS save written: " + SavePath);
        }
    }
}
