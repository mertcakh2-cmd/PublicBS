using UnityEngine;
using PublicBS.Bootstrap;

namespace PublicBS.Objects
{
    public static class DecorateObject
    {
        public static void Apply(GameObject target, Color color)
        {
            GameBootstrap.ApplyObjectMaterial(target, color);
        }
    }
}
