using UnityEngine;

namespace PublicBS.Objects
{
    public sealed class BuildObject : MonoBehaviour
    {
        public PrimitiveType Primitive { get; private set; }
        public Color Color { get; private set; }

        public void Initialize(PrimitiveType primitive, Color color)
        {
            Primitive = primitive;
            SetColor(color);
            gameObject.name = primitive + " Build Piece";
        }

        public void SetColor(Color color)
        {
            Color = color;
            PublicBS.Bootstrap.GameBootstrap.ApplyObjectMaterial(gameObject, color);
        }

        public BuildObjectData ToData()
        {
            return new BuildObjectData
            {
                primitive = Primitive.ToString(),
                position = transform.position,
                rotation = transform.eulerAngles,
                scale = transform.localScale,
                color = Color
            };
        }
    }
}
