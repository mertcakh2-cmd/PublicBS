using System;
using UnityEngine;

namespace PublicBS.Objects
{
    [Serializable]
    public sealed class BuildObjectData
    {
        public string primitive;
        public Vector3 position;
        public Vector3 rotation;
        public Vector3 scale;
        public Color color;
    }
}
