using UnityEngine;

namespace PublicBS.Objects
{
    public static class Placement
    {
        public static GameObject CreatePrimitive(PrimitiveType primitive, Vector3 groundPosition, Color color, Transform parent)
        {
            GameObject instance = GameObject.CreatePrimitive(primitive);
            instance.name = primitive + " Build Piece";
            instance.transform.SetParent(parent, true);
            Vector3 scale = DefaultScale(primitive);
            instance.transform.localScale = scale;
            instance.transform.position = new Vector3(groundPosition.x, scale.y * 0.5f, groundPosition.z);
            instance.AddComponent<BuildObject>().Initialize(primitive, color);
            instance.AddComponent<Rigidbody>().isKinematic = true;
            return instance;
        }

        public static Vector3 DefaultScale(PrimitiveType primitive)
        {
            switch (primitive)
            {
                case PrimitiveType.Sphere: return Vector3.one * 0.9f;
                case PrimitiveType.Capsule: return new Vector3(0.8f, 1.5f, 0.8f);
                case PrimitiveType.Cylinder: return new Vector3(0.9f, 1f, 0.9f);
                default: return Vector3.one;
            }
        }
    }
}
