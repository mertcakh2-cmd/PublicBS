using UnityEngine;

namespace PublicBS.Bootstrap
{
    [DefaultExecutionOrder(-1000)]
    public sealed class UnityStart : MonoBehaviour
    {
        private void Awake()
        {
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.SystemSetting;
            Screen.orientation = ScreenOrientation.LandscapeLeft;

            if (GetComponent<GameBootstrap>() == null)
                gameObject.AddComponent<GameBootstrap>();
        }
    }
}
