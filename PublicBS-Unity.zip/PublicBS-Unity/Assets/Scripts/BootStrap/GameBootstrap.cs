using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using PublicBS.Levels;
using PublicBS.Main;
using PublicBS.Settings;

namespace PublicBS.Bootstrap
{
    public sealed class GameBootstrap : MonoBehaviour
    {
        public static GameBootstrap Instance { get; private set; }

        public Camera GameCamera { get; private set; }
        public Transform BuildRoot { get; private set; }
        public PutObject Placement { get; private set; }
        public GameObject GridRoot { get; private set; }
        public StartGame GameState { get; private set; }
        public SoundSettings Sound { get; private set; }
        public AimAssist Aim { get; private set; }
        public float GridSize { get; private set; } = 1f;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        private void Start()
        {
            CreateWorld();
            CreateEventSystem();
            CreateInterface();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void CreateWorld()
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.34f, 0.40f, 0.52f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(0.055f, 0.075f, 0.12f);
            RenderSettings.fogMode = FogMode.Exponential;
            RenderSettings.fogDensity = 0.012f;

            GameObject cameraObject = new GameObject("PublicBS Camera");
            GameCamera = cameraObject.AddComponent<Camera>();
            GameCamera.tag = "MainCamera";
            GameCamera.fieldOfView = 52f;
            GameCamera.nearClipPlane = 0.1f;
            GameCamera.farClipPlane = 250f;
            GameCamera.clearFlags = CameraClearFlags.SolidColor;
            GameCamera.backgroundColor = new Color(0.035f, 0.055f, 0.095f);
            cameraObject.AddComponent<AudioListener>();
            OrbitCamera orbit = cameraObject.AddComponent<OrbitCamera>();
            orbit.SetTarget(Vector3.zero, 17f);

            GameObject lightObject = new GameObject("Soft Key Light");
            Light sun = lightObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.intensity = 1.25f;
            sun.color = new Color(0.80f, 0.88f, 1f);
            lightObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);

            BuildRoot = new GameObject("Placed Objects").transform;
            BuildRoot.SetParent(transform, false);

            GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            ground.name = "Build Floor";
            ground.transform.position = new Vector3(0f, -0.28f, 0f);
            ground.transform.localScale = new Vector3(32f, 0.5f, 32f);
            ApplyMaterial(ground, new Color(0.075f, 0.105f, 0.16f), 0.15f, 0.65f);

            GridRoot = new GameObject("Grid Lines");
            GridRoot.transform.SetParent(transform, false);
            CreateGridLines();

            Placement = gameObject.AddComponent<PutObject>();
            Placement.Initialize(GameCamera, BuildRoot);
            GameState = gameObject.AddComponent<StartGame>();
            Sound = gameObject.AddComponent<SoundSettings>();
            Aim = gameObject.AddComponent<AimAssist>();

            // A few starter structures make the arena feel alive without restricting building.
            Placement.PlaceAt(new Vector3(-3f, 0.5f, 1f), PrimitiveType.Cube, new Color(0.12f, 0.72f, 0.95f));
            Placement.PlaceAt(new Vector3(-1.8f, 0.5f, 1f), PrimitiveType.Cube, new Color(0.35f, 0.48f, 0.98f));
            Placement.PlaceAt(new Vector3(-2.4f, 1.5f, 1f), PrimitiveType.Sphere, new Color(0.43f, 0.88f, 0.77f));
        }

        private void CreateGridLines()
        {
            for (int i = -15; i <= 15; i++)
            {
                CreateGridLine(new Vector3(i, 0.002f, -15f), new Vector3(i, 0.002f, 15f));
                CreateGridLine(new Vector3(-15f, 0.002f, i), new Vector3(15f, 0.002f, i));
            }
        }

        private void CreateGridLine(Vector3 start, Vector3 end)
        {
            GameObject lineObject = new GameObject("Grid Line");
            lineObject.transform.SetParent(GridRoot.transform, false);
            LineRenderer line = lineObject.AddComponent<LineRenderer>();
            line.positionCount = 2;
            line.SetPosition(0, start);
            line.SetPosition(1, end);
            line.startWidth = 0.018f;
            line.endWidth = 0.018f;
            line.useWorldSpace = true;
            line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            line.receiveShadows = false;
            line.material = new Material(Shader.Find("Sprites/Default"));
            line.startColor = new Color(0.20f, 0.37f, 0.52f, 0.48f);
            line.endColor = line.startColor;
        }

        private static void ApplyMaterial(GameObject target, Color color, float metallic, float smoothness)
        {
            Renderer renderer = target.GetComponent<Renderer>();
            if (renderer == null) return;
            Material material = new Material(Shader.Find("Standard"));
            material.color = color;
            material.SetFloat("_Metallic", metallic);
            material.SetFloat("_Glossiness", smoothness);
            renderer.sharedMaterial = material;
        }

        private void CreateEventSystem()
        {
            if (FindObjectOfType<EventSystem>() != null) return;
            GameObject eventSystem = new GameObject("EventSystem");
            eventSystem.AddComponent<EventSystem>();
            eventSystem.AddComponent<StandaloneInputModule>();
        }

        private void CreateInterface()
        {
            GameObject canvasObject = new GameObject("PublicBS Interface");
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            CanvasScaler scaler = canvasObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600f, 900f);
            scaler.matchWidthOrHeight = 0.5f;
            canvasObject.AddComponent<GraphicRaycaster>();
            Startinterface ui = canvasObject.AddComponent<Startinterface>();
            ui.Initialize(this);
            gameObject.AddComponent<BetaWaterMark>();
        }

        public void SetGridVisible(bool visible)
        {
            if (GridRoot != null) GridRoot.SetActive(visible);
        }

        public void SetGridSize(float size)
        {
            GridSize = Mathf.Clamp(size, 0.5f, 2f);
        }

        public static void ApplyObjectMaterial(GameObject target, Color color)
        {
            Renderer renderer = target.GetComponent<Renderer>();
            if (renderer == null) return;
            Material material = new Material(Shader.Find("Standard"));
            material.color = color;
            material.SetFloat("_Metallic", 0.18f);
            material.SetFloat("_Glossiness", 0.72f);
            renderer.material = material;
        }
    }
}
