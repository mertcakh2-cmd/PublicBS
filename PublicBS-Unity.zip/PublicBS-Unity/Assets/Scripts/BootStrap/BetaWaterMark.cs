using UnityEngine;
using UnityEngine.UI;

namespace PublicBS.Bootstrap
{
    public sealed class BetaWaterMark : MonoBehaviour
    {
        private void Start()
        {
            Canvas canvas = FindObjectOfType<Canvas>();
            if (canvas == null) return;
            GameObject labelObject = new GameObject("PublicBS Watermark", typeof(RectTransform), typeof(Text));
            labelObject.transform.SetParent(canvas.transform, false);
            RectTransform rect = labelObject.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(1f, 0f);
            rect.pivot = new Vector2(1f, 0f);
            rect.anchoredPosition = new Vector2(-24f, 132f);
            rect.sizeDelta = new Vector2(300f, 26f);
            Text label = labelObject.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            label.fontSize = 12;
            label.fontStyle = FontStyle.Bold;
            label.alignment = TextAnchor.MiddleRight;
            label.color = new Color(0.48f, 0.64f, 0.78f, 0.7f);
            label.text = "PUBLICBS  •  CREATIVE BUILD";
            label.raycastTarget = false;
        }
    }
}
