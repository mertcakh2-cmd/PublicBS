using UnityEngine;
using UnityEngine.EventSystems;

namespace PublicBS.Bootstrap
{
    public sealed class OrbitCamera : MonoBehaviour
    {
        private Vector3 target;
        private float distance = 17f;
        private float yaw = 42f;
        private float pitch = 28f;
        private const float MinPitch = 12f;
        private const float MaxPitch = 78f;

        public void SetTarget(Vector3 point, float startDistance)
        {
            target = point;
            distance = startDistance;
            ApplyTransform();
        }

        private void Update()
        {
            if (Input.touchCount > 0)
            {
                Touch touch = Input.GetTouch(0);
                if (touch.phase == TouchPhase.Moved && !IsOverUI(touch.fingerId))
                {
                    yaw += touch.deltaPosition.x * 0.16f;
                    pitch -= touch.deltaPosition.y * 0.12f;
                    pitch = Mathf.Clamp(pitch, MinPitch, MaxPitch);
                }
                if (Input.touchCount >= 2)
                {
                    Touch second = Input.GetTouch(1);
                    Vector2 previousA = touch.position - touch.deltaPosition;
                    Vector2 previousB = second.position - second.deltaPosition;
                    float previous = Vector2.Distance(previousA, previousB);
                    float current = Vector2.Distance(touch.position, second.position);
                    distance = Mathf.Clamp(distance - (current - previous) * 0.012f, 6f, 36f);
                }
            }
            else
            {
                if (Input.GetMouseButton(1) && !IsOverUI(-1))
                {
                    yaw += Input.GetAxis("Mouse X") * 4f;
                    pitch -= Input.GetAxis("Mouse Y") * 3f;
                    pitch = Mathf.Clamp(pitch, MinPitch, MaxPitch);
                }
                distance = Mathf.Clamp(distance - Input.mouseScrollDelta.y * 1.15f, 6f, 36f);
            }
            ApplyTransform();
        }

        private bool IsOverUI(int pointerId)
        {
            return EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(pointerId);
        }

        private void ApplyTransform()
        {
            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
            transform.position = target + rotation * new Vector3(0f, 0f, -distance);
            transform.rotation = rotation;
        }
    }
}
