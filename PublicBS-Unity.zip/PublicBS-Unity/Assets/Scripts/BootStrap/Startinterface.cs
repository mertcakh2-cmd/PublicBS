using UnityEngine;
using UnityEngine.UI;
using PublicBS.Levels;
using PublicBS.Settings;

namespace PublicBS.Bootstrap
{
    public sealed class Startinterface : MonoBehaviour
    {
        private GameBootstrap game;
        private Text toastText;
        private GameObject settingsPanel;
        private settingsUI settings;
        private Font uiFont;

        public void Initialize(GameBootstrap bootstrap)
        {
            game = bootstrap;
            uiFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
            BuildHeader(transform as RectTransform);
            BuildToolbar(transform as RectTransform);
            BuildToast(transform as RectTransform);
            settings = game.gameObject.AddComponent<settingsUI>();
            BuildSettings(transform as RectTransform);
        }

        private void BuildHeader(RectTransform root)
        {
            GameObject panel = Panel("Header", root, new Color(0.025f, 0.045f, 0.08f, 0.94f));
            Anchor(panel, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, 0f), new Vector2(0f, 88f));
            Text title = Label("PUBLICBS", panel.transform, 30, FontStyle.Bold, new Color(0.92f, 0.97f, 1f), TextAnchor.MiddleLeft);
            Anchor(title.gameObject, new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(0f, 0.5f), new Vector2(32f, 0f), new Vector2(290f, 0f));
            Text subtitle = Label("CREATIVE BUILD SANDBOX  /  BUILD ANYTHING", panel.transform, 13, FontStyle.Normal, new Color(0.48f, 0.67f, 0.82f), TextAnchor.MiddleLeft);
            Anchor(subtitle.gameObject, new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(0f, 0.5f), new Vector2(300f, 0f), new Vector2(500f, 0f));
            Text status = Label("●  CREATIVE MODE     LOCAL WORLD", panel.transform, 14, FontStyle.Bold, new Color(0.37f, 0.88f, 0.73f), TextAnchor.MiddleRight);
            Anchor(status.gameObject, new Vector2(1f, 0f), new Vector2(1f, 1f), new Vector2(1f, 0.5f), new Vector2(-30f, 0f), new Vector2(390f, 0f));
        }

        private void BuildToolbar(RectTransform root)
        {
            GameObject panel = Panel("Build Toolbar", root, new Color(0.025f, 0.045f, 0.08f, 0.96f));
            Anchor(panel, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 0f), new Vector2(0f, 126f));
            HorizontalLayoutGroup row = panel.AddComponent<HorizontalLayoutGroup>();
            row.padding = new RectOffset(18, 18, 16, 16);
            row.spacing = 10f;
            row.childAlignment = TextAnchor.MiddleCenter;
            row.childControlWidth = true;
            row.childControlHeight = true;
            row.childForceExpandWidth = true;
            row.childForceExpandHeight = true;

            AddButton(panel.transform, "CUBE", new Color(0.12f, 0.48f, 0.68f), () => { game.Placement.SetSelectedPrimitive(PrimitiveType.Cube); Notify("CUBE SELECTED  •  TAP THE ARENA TO BUILD"); });
            AddButton(panel.transform, "SPHERE", new Color(0.18f, 0.42f, 0.61f), () => { game.Placement.SetSelectedPrimitive(PrimitiveType.Sphere); Notify("SPHERE SELECTED"); });
            AddButton(panel.transform, "CAPSULE", new Color(0.18f, 0.42f, 0.61f), () => { game.Placement.SetSelectedPrimitive(PrimitiveType.Capsule); Notify("CAPSULE SELECTED"); });
            AddButton(panel.transform, "CYLINDER", new Color(0.18f, 0.42f, 0.61f), () => { game.Placement.SetSelectedPrimitive(PrimitiveType.Cylinder); Notify("CYLINDER SELECTED"); });
            AddButton(panel.transform, "DELETE", new Color(0.58f, 0.22f, 0.28f), () => { game.Placement.ToggleDeleteMode(); Notify(game.Placement.DeleteMode ? "DELETE MODE  •  TAP AN OBJECT" : "BUILD MODE"); });
            AddButton(panel.transform, "ROTATE", new Color(0.36f, 0.32f, 0.63f), () => { game.Placement.RotateLast(); Notify("OBJECT ROTATED"); });
            AddButton(panel.transform, "SAVE", new Color(0.12f, 0.50f, 0.40f), () => { game.Placement.SaveWorld(); Notify("WORLD SAVED ON THIS DEVICE"); });
            AddButton(panel.transform, "LOAD", new Color(0.12f, 0.43f, 0.42f), () => { bool loaded = game.Placement.LoadWorld(); Notify(loaded ? "WORLD LOADED" : "NO SAVE FOUND YET"); });
            AddButton(panel.transform, "CLEAR", new Color(0.42f, 0.28f, 0.30f), () => { game.Placement.ClearWorld(); Notify("BUILD AREA CLEARED"); });
            AddButton(panel.transform, "SETTINGS", new Color(0.21f, 0.27f, 0.39f), () => ToggleSettings());
        }

        private void BuildToast(RectTransform root)
        {
            toastText = Label("", root, 16, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter);
            toastText.gameObject.AddComponent<Outline>().effectColor = new Color(0f, 0f, 0f, 0.6f);
            Anchor(toastText.gameObject, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 138f), new Vector2(820f, 42f));
            toastText.gameObject.SetActive(false);
        }

        private void BuildSettings(RectTransform root)
        {
            settingsPanel = Panel("Settings Panel", root, new Color(0.035f, 0.06f, 0.10f, 0.98f));
            Anchor(settingsPanel, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(520f, 350f));
            Text heading = Label("WORLD SETTINGS", settingsPanel.transform, 25, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter);
            Anchor(heading.gameObject, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -28f), new Vector2(0f, 56f));
            AddPanelButton(settingsPanel.transform, "TOGGLE GRID", new Vector2(0f, 45f), () =>
            {
                bool next = !game.GridRoot.activeSelf;
                game.SetGridVisible(next);
                Notify(next ? "GRID ENABLED" : "GRID HIDDEN");
            });
            AddPanelButton(settingsPanel.transform, "SOUND ON / OFF", new Vector2(0f, -25f), () =>
            {
                game.Sound.Toggle();
                Notify(game.Sound.IsMuted ? "SOUND MUTED" : "SOUND ENABLED");
            });
            AddPanelButton(settingsPanel.transform, "CLOSE", new Vector2(0f, -115f), () => ToggleSettings(false));
            settingsPanel.SetActive(false);
        }

        private void AddPanelButton(Transform parent, string caption, Vector2 position, UnityEngine.Events.UnityAction action)
        {
            Button button = CreateButton(parent, caption, new Color(0.12f, 0.30f, 0.43f), action);
            RectTransform rect = button.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = new Vector2(330f, 58f);
        }

        private void AddButton(Transform parent, string caption, Color color, UnityEngine.Events.UnityAction action)
        {
            Button button = CreateButton(parent, caption, color, action);
            LayoutElement layout = button.gameObject.AddComponent<LayoutElement>();
            layout.minWidth = 105f;
            layout.preferredWidth = 150f;
            layout.flexibleWidth = 1f;
            layout.minHeight = 72f;
        }

        private Button CreateButton(Transform parent, string caption, Color color, UnityEngine.Events.UnityAction action)
        {
            GameObject buttonObject = Panel(caption + " Button", parent, color);
            Button button = buttonObject.AddComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = color;
            colors.highlightedColor = Color.Lerp(color, Color.white, 0.16f);
            colors.pressedColor = Color.Lerp(color, Color.black, 0.16f);
            colors.selectedColor = colors.highlightedColor;
            button.colors = colors;
            button.targetGraphic = buttonObject.GetComponent<Image>();
            button.onClick.AddListener(action);
            Text label = Label(caption, buttonObject.transform, 16, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter);
            Stretch(label.rectTransform, 0f);
            return button;
        }

        private GameObject Panel(string name, Transform parent, Color color)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(parent, false);
            obj.GetComponent<Image>().color = color;
            return obj;
        }

        private Text Label(string value, Transform parent, int size, FontStyle style, Color color, TextAnchor alignment)
        {
            GameObject obj = new GameObject("Text - " + value, typeof(RectTransform), typeof(Text));
            obj.transform.SetParent(parent, false);
            Text text = obj.GetComponent<Text>();
            text.text = value;
            text.font = uiFont;
            text.fontSize = size;
            text.fontStyle = style;
            text.color = color;
            text.alignment = alignment;
            text.horizontalOverflow = HorizontalWrapMode.Overflow;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            return text;
        }

        private void Stretch(RectTransform rect, float inset)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(inset, inset);
            rect.offsetMax = new Vector2(-inset, -inset);
        }

        private void Anchor(GameObject obj, Vector2 min, Vector2 max, Vector2 pivot, Vector2 position, Vector2 size)
        {
            RectTransform rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = min;
            rect.anchorMax = max;
            rect.pivot = pivot;
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
        }

        public void Notify(string message)
        {
            if (toastText == null) return;
            CancelInvoke(nameof(HideToast));
            toastText.text = message;
            toastText.gameObject.SetActive(true);
            Invoke(nameof(HideToast), 2.25f);
        }

        private void HideToast()
        {
            if (toastText != null) toastText.gameObject.SetActive(false);
        }

        public void ToggleSettings(bool? force = null)
        {
            if (settingsPanel == null) return;
            settingsPanel.SetActive(force ?? !settingsPanel.activeSelf);
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape)) ToggleSettings();
        }
    }
}
