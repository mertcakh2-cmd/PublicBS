using System;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace PublicBS.Networking
{
    public static class FetchDotNetRes
    {
        public static async Task<string> GetText(string url)
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out Uri uri) ||
                (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp))
                throw new ArgumentException("A valid HTTP or HTTPS URL is required.", nameof(url));

            using (UnityWebRequest request = UnityWebRequest.Get(uri))
            {
                UnityWebRequestAsyncOperation operation = request.SendWebRequest();
                while (!operation.isDone) await Task.Yield();
                if (request.result != UnityWebRequest.Result.Success)
                    throw new InvalidOperationException(request.error);
                return request.downloadHandler.text;
            }
        }
    }
}
