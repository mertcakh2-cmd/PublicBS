using System;
using System.Threading.Tasks;

namespace PublicBS.Networking
{
    public static class GetDotNET
    {
        public static async Task<T> GetJson<T>(string url)
        {
            string json = await FetchDotNetRes.GetText(url);
            T value = UnityEngine.JsonUtility.FromJson<T>(json);
            if (value == null) throw new InvalidOperationException("The response could not be parsed as the requested type.");
            return value;
        }
    }
}
