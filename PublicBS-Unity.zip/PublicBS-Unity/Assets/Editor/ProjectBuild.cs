using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;
using PublicBS.Bootstrap;

namespace PublicBS.Editor
{
    public static class ProjectBuild
    {
        private const string ScenePath = "Assets/Scenes/Main.unity";

        [MenuItem("PublicBS/Generate Main Scene")]
        public static void GenerateMainScene()
        {
            Directory.CreateDirectory("Assets/Scenes");
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GameObject bootstrap = new GameObject("PublicBS Bootstrap");
            bootstrap.AddComponent<UnityStart>();
            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("PublicBS Main scene created at " + ScenePath);
        }

        private static void PrepareProject()
        {
            if (!File.Exists(ScenePath)) GenerateMainScene();
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            PlayerSettings.companyName = "PublicBS";
            PlayerSettings.productName = "PublicBS Sandbox";
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.defaultScreenWidth = 1600;
            PlayerSettings.defaultScreenHeight = 900;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.runInBackground = true;
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.publicbs.sandbox");
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Standalone, ScriptingImplementation.Mono2x);
            EditorUserBuildSettings.buildAppBundle = false;
        }

        public static void BuildAndroid()
        {
            PrepareProject();
            Build(BuildTarget.Android, "Builds/Android/PublicBS.apk");
        }

        public static void BuildWindows()
        {
            PrepareProject();
            Build(BuildTarget.StandaloneWindows64, "Builds/Windows/PublicBS.exe");
        }

        private static void Build(BuildTarget target, string outputPath)
        {
            string directory = Path.GetDirectoryName(outputPath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            string[] scenes = EditorBuildSettings.scenes.Where(scene => scene.enabled).Select(scene => scene.path).ToArray();
            if (scenes.Length == 0) throw new InvalidOperationException("No enabled scenes were found in Build Settings.");

            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = outputPath,
                target = target,
                options = BuildOptions.None
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
                throw new Exception("PublicBS build failed: " + report.summary.result + " - " + report.summary.totalErrors + " error(s).");

            Debug.Log("PublicBS build complete: " + Path.GetFullPath(outputPath));
        }
    }
}
